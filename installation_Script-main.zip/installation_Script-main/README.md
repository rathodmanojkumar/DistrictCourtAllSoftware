# Installation_Script
script for install the drivers on epson printers and other softwares like dict and proxykey

you need to download only the install script 
